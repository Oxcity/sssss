###Setup 

Click on 🔒 lock icon
 
Then Put in Key : TOKEN
value is : Your bot token

then click on run

if u geting error join support servers 

### Support server's 

Zero 0_0#6666 |  https://discord.gg/EmAVnzT2pe

Cwkhan </ Cw khan >#5764 | 
https://discord.gg/my8EBqR624